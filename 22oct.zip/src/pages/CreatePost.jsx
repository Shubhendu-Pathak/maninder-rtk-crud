import React from 'react'

function CreatePost() {
  return (
    <div>CreatePost</div>
  )
}

export default CreatePost