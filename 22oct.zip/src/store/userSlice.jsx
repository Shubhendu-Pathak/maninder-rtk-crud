import { createSlice } from "@reduxjs/toolkit";
import { deleteuser, showuser, updateuser } from "./thunk/fetch";


let userSlicedata = createSlice({
    name: 'users',
 initialState:{
    isloading: false, data: null, error : null
 }, 
 reducers:{
    logout(state, action){
        state.data = null
    }
 },
 extraReducers(builder){
    // get
builder.addCase(showuser.pending,(state, action)=>{
state.isloading = true
}),
builder.addCase(showuser.fulfilled,(state, action)=>{
    state.data = action.payload
    state.isloading = false
    state.error = null
}),
builder.addCase(showuser.rejected,(state, action)=>{
    state.isloading = false
    state.data = null
    state.error = action.payload
})
      // get
    //   delete
    builder.addCase(deleteuser.pending,(state, action)=>{
        state.isloading = true
        }),
    builder.addCase(deleteuser.fulfilled,(state, action)=>{
            state.isloading = false
            state.error = null
            console.log(action.payload);
            
            let {id} = action.payload
            if(id){
                state.data = state.data.filter((item) => item.id != id)
            }
        }),
    builder.addCase(deleteuser.rejected,(state, action)=>{
            state.isloading = false
            state.data = null
            state.error = action.payload
        })
    // delete
    // update
    builder.addCase(updateuser.pending,(state, action)=>{
        state.isloading = true
        }),
    builder.addCase(updateuser.fulfilled,(state, action)=>{
            state.isloading = false
            state.error = null
            console.log(action.payload);
        state.data = state.data.map(ele=>{
            return ele.id == action.payload.id ? action.payload : ele
        })
        }),
    builder.addCase(updateuser.rejected,(state, action)=>{
            state.isloading = false
            state.data = null
            state.error = action.payload
        })
// update
 }
})

export const {logout} = userSlicedata.actions
export const userdata = userSlicedata.reducer